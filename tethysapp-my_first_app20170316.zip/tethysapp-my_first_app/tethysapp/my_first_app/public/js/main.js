var map, layers, ColoniesPoly, Philli, DelawareRiver, AnnapolisConvention, Boston, CitiesOfShaysRebellion, Courthoues, SigningConst, Articles, ConstCon, EndRev, StartRev, Sugar;

$("input").change(function () {
    var layers=map.getLayers().a;
    if (this.checked) {
        if (this.id=="all") {
            document.getElementById("none").checked = false;
            document.getElementById("Colonies").checked = true;
            document.getElementById("DelRiv").checked = true;
            document.getElementById("Boston").checked = true;
            document.getElementById("Philli").checked = true;
            document.getElementById("Sugar").checked = true;
            document.getElementById("StartRev").checked = true;
            document.getElementById("SignDec").checked = true;
            document.getElementById("Articles").checked = true;
            document.getElementById("EndRev").checked = true;
            document.getElementById("AnnCon").checked = true;
            document.getElementById("Shay").checked = true;
            document.getElementById("Court").checked = true;
            document.getElementById("ConstCon").checked = true;
            document.getElementById("SignConst").checked = true;
            for (var i=1; i <= 14; i++) {
                layers[i].setVisible(true);
            }
        } else if (this.id=="none") {
            document.getElementById("all").checked = false;
            document.getElementById("Colonies").checked = false;
            document.getElementById("DelRiv").checked = false;
            document.getElementById("Boston").checked = false;
            document.getElementById("Philli").checked = false;
            document.getElementById("Sugar").checked = false;
            document.getElementById("StartRev").checked = false;
            document.getElementById("SignDec").checked = false;
            document.getElementById("Articles").checked = false;
            document.getElementById("EndRev").checked = false;
            document.getElementById("AnnCon").checked = false;
            document.getElementById("Shay").checked = false;
            document.getElementById("Court").checked = false;
            document.getElementById("ConstCon").checked = false;
            document.getElementById("SignConst").checked = false;
            for (var i=1; i <= 14; i++) {
                layers[i].setVisible(false);
            }
        } else {
            document.getElementById("all").checked = false;
            document.getElementById("none").checked = false;
            for (var i=1; i <= 14; i++) {
                if (layers[i].name==this.id) {
                    layers[i].setVisible(true);
                }
            }
        }
    } else {
        document.getElementById("all").checked = false;
        document.getElementById("none").checked = false;
         for (var i=1; i <= 14; i++) {
            if (layers[i].name==this.id) {
                layers[i].setVisible(false);
            }
         }
    }
});

function DoTheThing(Zhuli) {
    console.log("Merrick calls");
    console.log(Zhuli);
    switch(Zhuli)
    {
        case "ColoniesPoly":
            console.log("found the case");
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 4
            }))
            break;

        case "Philli":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-75.1652,39.9526], 'EPSG:3857'),
                zoom: 13
            }))
            break;
        case "DelawareRiver":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-75.6333,39.2701], 'EPSG:3857'),
                zoom: 5
            }))
            break;
        case "AnnapolisConvention":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-76.4922,38.9784], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "Boston":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-71.0589,42.3601], 'EPSG:3857'),
                zoom: 13
            }))
            break;
        case "CitiesofShaysRebellion":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-72.073637,42.358933], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "Courthoues":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-72.073637,42.358933], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "SigningConst":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "SigningDec":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "Articles":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "ConstCon":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "EndRev":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-40.785660,35.034794], 'EPSG:3857'),
                zoom: 4
            }))
            break;
        case "StartRev":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
        case "Sugar":
            map.setView(new ol.View({
                center: ol.proj.fromLonLat([-77.0369,38.9072], 'EPSG:3857'),
                zoom: 9
            }))
            break;
    }
}

function init() {

    var projection = ol.proj.get('EPSG:3857');

    ColoniesPoly = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/ColoniesPoly.kml',
        format: new ol.format.KML()
        })
    });
    ColoniesPoly.name = "Colonies"

    Philli = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/Philli.kml',
        format: new ol.format.KML()
        })
    });
    Philli.name ="Philli"

    var DelawareRiver = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/DelawareRiver.kml',
        format: new ol.format.KML()
        })
    });
    DelawareRiver.name = "DelRiv"

    var AnnapolisConvention = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/AnnapolisConvention.kml',
        format: new ol.format.KML()
        })
    });
    AnnapolisConvention.name = "AnnCon"

    var Boston = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/Boston.kml',
        format: new ol.format.KML()
        })
    });
    Boston.name = "Boston"

    var CitiesOfShaysRebellion = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/CitiesOfShaysRebellion.kml',
        format: new ol.format.KML()
        })
    });
    CitiesOfShaysRebellion.name = "Shay"

     var Courthoues = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/Courthoues.kml',
        format: new ol.format.KML()
        })
    });
    Courthoues.name = "Court"

    var SigningConst = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/SigningConst.kml',
        format: new ol.format.KML()
        })
    });
    SigningConst.name = "SignConst"

    var SigningDec = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/SigningDec.kml',
        format: new ol.format.KML()
        })
    });
    SigningDec.name = "SignDec"

    var Articles = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/ArticlesAdopted.kml',
        format: new ol.format.KML()
        })
    });
    Articles.name = "Articles"

    var ConstCon = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/ConstitutionalConvention.kml',
        format: new ol.format.KML()
        })
    });
    ConstCon.name = "ConstCon"

    var EndRev = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/EndofRevolutin.kml',
        format: new ol.format.KML()
        })
    });
    EndRev.name = "EndRev"

    var StartRev = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/StartShot.kml',
        format: new ol.format.KML()
        })
    });
    StartRev.name = "StartRev"

    var Sugar = new ol.layer.Vector({
        source: new ol.source.Vector({
        projection: projection,
        url: '/static/my_first_app/KML/SugarActCountries.kml',
        format: new ol.format.KML()
        })
    });
    Sugar.name = "Sugar"

    var basemap = new ol.layer.Tile({
            source: new ol.source.OSM()
    })

    map = new ol.Map({
        layers: [basemap, ColoniesPoly, Philli, DelawareRiver, AnnapolisConvention, Boston, CitiesOfShaysRebellion, Courthoues, SigningConst, SigningDec, Articles, ConstCon, EndRev, StartRev, Sugar],
        target: 'map',
        view: new ol.View({
        center: [-8514445.563749928,4418610.354066202],
        zoom:4.75
        })
    });

    document.getElementById("all").checked = true;
    document.getElementById("none").checked = false;
    document.getElementById("Colonies").checked = true;
    document.getElementById("DelRiv").checked = true;
    document.getElementById("Boston").checked = true;
    document.getElementById("Philli").checked = true;
    document.getElementById("Sugar").checked = true;
    document.getElementById("StartRev").checked = true;
    document.getElementById("SignDec").checked = true;
    document.getElementById("Articles").checked = true;
    document.getElementById("EndRev").checked = true;
    document.getElementById("AnnCon").checked = true;
    document.getElementById("Shay").checked = true;
    document.getElementById("Court").checked = true;
    document.getElementById("ConstCon").checked = true;
    document.getElementById("SignConst").checked = true;
    var layers=map.getLayers().a;
    for (var i=1; i <= 14; i++) {
        layers[i].setVisible(true);
    }

    var element = document.getElementById('popup');

    var popup = new ol.Overlay({
        element: element,
        positioning: 'bottom-center',
        stopEvent: false,
        offset: [0, -50]
      });
    map.addOverlay(popup);

      // display popup on click
    map.on('click', function(evt) {
        //alert('just clicked');
        var feature = map.forEachFeatureAtPixel(evt.pixel,
            function(feature) {
              return feature;
            });
            //alert('clicked');
        if (feature) {
          var coordinates = feature.getGeometry().getCoordinates();
          popup.setPosition(coordinates);
          $(element).popover({
            'placement': 'top',
            'html': true,
            'content': feature.get('description')
          });
          $(element).popover('show');
        } else {
          $(element).popover('destroy');
        }
      });


}

function setZoom(blargh) {
    console.log('It registered the dropdown change.');
    console.log(blargh);
    DoTheThing(blargh);
}

